# Card View []({{ site.repo }}/blob/master/docs/_i18n/{{ site.lang }}/examples/card-view.md)

Use la opción `cardView: true` para mostrar la vista de tarjeta. _by [@wenzhixin](https://github.com/wenzhixin)_

<iframe width="100%" height="300" data-src="http://jsfiddle.net/wenyi/e3nk137y/27/embedded/html,result" allowfullscreen="allowfullscreen" frameborder="0"></iframe>